﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stok_Takip
{
    public partial class YeniKullanici : Form
    {
        public YeniKullanici()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection("server=.;Initial Catalog=StokDB;Integrated Security=SSPI");
        DialogResult dialog = new DialogResult();
        SqlDataAdapter da;
        SqlCommand command;
        string verify = "19052000";
        bool situation;

        private void btnsignup_Click(object sender, EventArgs e)
        {
            if (txtpassword.Text == txtrepassword.Text)
            {
                if (txtverify.Text == verify)
                {
                    SqlConnection baglanti = new SqlConnection("server=.;Initial Catalog=StokDB;Integrated Security=SSPI");
                    baglanti.Open();
                    SqlCommand command = new SqlCommand("insert into Kullanıcılar (Username,Password) values ('" + txtusername.Text.ToString() + "','"
                        + txtpassword.Text.ToString() + "'  )", baglanti);
                    command.ExecuteNonQuery();
                    baglanti.Close();
                    MessageBox.Show("Kayıt işlemi başarı ile gerçekleşti", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Close();
                }
                else
                {
                    dialog = MessageBox.Show("Referans Kodunu Kontrol Ediniz ! ", "Hata", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    if (dialog == DialogResult.Cancel)
                    {
                        Application.Exit();
                    }
                }
            }
            else
            {
                dialog = MessageBox.Show("Şifreler Birbirleri ile Uyuşmuyor ! ", "Hata", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                if (dialog == DialogResult.Cancel)
                {
                    Application.Exit();
                }
            }
        }

        private void YeniKullanici_Load(object sender, EventArgs e)
        {
            panel1.BackColor = Color.FromArgb(100, 0, 0, 0);
        }
    }
}
