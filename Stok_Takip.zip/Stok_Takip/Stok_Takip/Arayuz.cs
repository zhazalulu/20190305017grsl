﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stok_Takip
{
    public partial class Arayuz : Form
    {
        public Arayuz()
        {
            InitializeComponent();
        }
        Login login = new Login();
        YeniKullanici yeni = new YeniKullanici();

        private void girişYapToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            login.Show();
            login.Location = new Point(-11, 46);
        }

        private void yeniKayıtToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            yeni.Show();
            yeni.Location = new Point(-11, 46);
        }

        private void çıkışYapToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            DialogResult dialog = new DialogResult();
            dialog = MessageBox.Show("Çıkış Yapmak Üzeresiniz.\nÇıkış Yapmak İstediğinizden Emin Misiniz ?", "Bilgi", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (dialog == DialogResult.OK)
            {

                Application.Exit();

            }
        }
    }
}
