Referans Kodu :19052000
Login kullanıcı adı = admin 
şifre = 1234